const mongoose= require('mongoose');


const USchema= new mongoose.Schema({
    name:{
        type:String,
        required:true,
        minlength:2,
        maxlength:125
    },
    p:{
        type:String,
        required:true,
    },
    reason:{
        type:String,
        default:'enter reason..'
    }
});
const University= mongoose.model('University',USchema);
module.exports.University= University;