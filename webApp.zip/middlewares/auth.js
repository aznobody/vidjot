
//In this middleware either we need to stop the req-res cycle by sending the response
//or
//move on to the next modifications
async function auth(req,res,next)
{
   if(req.isAuthenticated())
   next();
   else
   {req.flash('info_msg','Please Login first');
   res.redirect('/users/login');}
}
module.exports=auth;