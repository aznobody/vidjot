module.exports={
    currentUser:function(block){
        return global.currentUser;
    },
    ifObj:function(item, options) {
        if(typeof item == "string") {
          return options.fn(this);
        } else {
          return options.inverse(this);
        }
      }
}