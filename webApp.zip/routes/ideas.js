const express= require('../../exp1UsingMongoDB/express');
const routes= express.Router();
const {Idea} = require('../models/Idea');
const auth=require('../middlewares/auth');
//Add Idea
routes.get('/add',auth, (req, res) => {
    res.render('ideas/add');
})

routes.get('/edit/:id',auth, (req, res) => {
    Idea.findOne({ _id: req.params.id}) 
        .then((idea) => {
            //only same user who created idea should be able to edit
            if(idea.userId!=req.user.id)
            {
                req.flash('error_msg','Unauthorized');
                res.redirect('/ideas');
            }
            else
            {
                res.render('ideas/edit', {
                    idea: idea
                })
            }
        })
})


//GET ALL ideas
routes.get('/',auth,(req, res) => {
    Idea.find({userId:req.user.id})
        .then((ideas) => {
            res.render('ideas/index', {
                ideas: ideas
            });
        })
})


routes.post('/',auth, (req, res) => {
    var errors = [];
    if (!req.body.title)
        errors.push('please enter title');
    if (!req.body.description)
        errors.push('please enter description');
    if (errors.length > 0) {
        res.render('ideas/add', {
            errors: errors,
            title: req.body.title,
            description: req.body.description
        })
    }
    else {
        const idea = new Idea({
            title: req.body.title,
            userId: req.user.id,
            description: req.body.description
        });
        idea.save()
            .then((idea) => {
                req.flash('success_msg', 'Video Idea Added Successfully!');
                res.redirect('/ideas');
            })
    }
})

routes.get('/about',auth, (req, res) => {
    res.render('about');
})

routes.put('/:id',auth, (req, res) => {
    Idea.findOne({ _id: req.params.id })
        .then((idea) => {
            //to save edits from postman using PUT requests
            if(idea.userId!=req.user.id)
            {
                req.flash('error_msg','Unauthorized');
                res.redirect('/ideas');
            }
            else{
                idea.title = req.body.title;
                idea.description = req.body.description;
                idea.save()
                .then((idea) => {                    
                    req.flash('success_msg', 'Video Idea Updated Successfully!');
                    res.redirect('/ideas')
                })
            }
            
        })
})

routes.delete('/:id',auth, (req, res) => {
    Idea.findOne({ _id: req.params.id })
        .then((idea) => {
            //to save deletes from postman using DELETE requests
            if(idea.userId!=req.user.id)
            {
                req.flash('error_msg','Unauthorized');
                res.redirect('/ideas');
            }
            else{
                Idea.remove({ _id: req.params.id })
                .then((idea) => {
                req.flash('success_msg', 'Video Idea Deleted Successfully!');
                res.redirect('/ideas')
            })
            }   
        })        
    })

module.exports=routes;
