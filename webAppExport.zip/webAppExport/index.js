const path=require('path');
const flash = require('connect-flash');
const session = require('express-session');
const methodOverride = require('method-override');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const express = require('../exp1UsingMongoDB/express');
const exphbs = require('express-handlebars');
const msRouter= require('../webApp/routes/ms');
const ideasRouter= require('../webApp/routes/ideas');
const usersRouter= require('../webApp/routes/users');
const passport= require('passport');
const db=require('../webApp/config/db');
let app = express();



mongoose.Promise = global.Promise;

mongoose.connect(db.mongoURI, { useNewUrlParser: true })
    .then(() => console.log('Connected to MongoDB...'))
    .catch((err) => console.error('Could not connect to MongoDB', err))

//create a handlebar engine with default layout
const {currentUser,ifObj}=require('../webApp/config/helper');
app.engine('handlebars',exphbs({
    helpers:{
        currentUser:currentUser,
        ifObj:ifObj
    },
    defaultLayout:'main'
}));
//tell the app to use handlebars as view engine
app.set('view engine', 'handlebars');

//set body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//use public folder as static library 
app.use(express.static(path.join(__dirname,'public')));

//method override middleware fro PUT and DELETE requests
app.use(methodOverride('_method'));

//use session and flash middleware for flash messages and errors
app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));

//passporrt config
require('../webApp/config/passport')(passport);

//passport session
app.use(passport.initialize());
app.use(passport.session());

//to display flash messages
app.use(flash());

//global message and error values
app.use(function (req, res, next) {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.info_msg = req.flash('info_msg');
    res.locals.error = req.flash('error');
    res.locals.user = req.user;//the logged in user by passport
    next();
});
//set routes
app.use('/ms',msRouter);
app.use('/ideas',ideasRouter);
app.use('/users',usersRouter);

//start server
const port= process.env.PORT||81
app.listen(port, () => console.log('Server started on port'+port+'..'));

module.exports.applocals=app.locals;