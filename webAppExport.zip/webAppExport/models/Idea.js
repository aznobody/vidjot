const mongoose= require('mongoose');


const IdeaSchema= new mongoose.Schema({
    title:{
        type:String,
        required:true,
        minlength:2,
        maxlength:125
    },
    description:{
        type:String,
        required:true,
    },
    userId:{
        type:String,
        required:true
    },
    date:{
        type:Date,
        default:Date.now
    }
});
const Idea= mongoose.model('Idea',IdeaSchema);
module.exports.Idea= Idea;