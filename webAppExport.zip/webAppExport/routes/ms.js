const express= require('../../exp1UsingMongoDB/express');
const routes= express.Router();
const { University } = require('../models/University');



routes.get('/add', (req, res) => {
    res.render('ms/add');
})

routes.get('/edit/:id', (req, res) => {
    University.findOne({ _id: req.params.id })
        .then((idea) => {
            res.render('ms/edit', {
                idea: idea
            })
        })
})

routes.get('/',(req,res)=>{
    University.find({})
    .then((ideas) => {
        res.render('ms/index', {
            univ: ideas
        });
    })
})

routes.post('/', (req, res) => {
    const idea = new University({
        name: req.body.name,
        p: req.body.p
    });
    idea.save()
        .then((idea) => {
            req.flash('success_msg', 'Video Idea Added Successfully!');
            res.redirect('/ms');
        })
})

routes.delete('/:id', (req, res) => {
    University.remove({ _id: req.params.id })
        .then((idea) => {
            req.flash('success_msg', 'Data Deleted Successfully!');
            res.redirect('/ms')
        })
})

routes.put('/:id', (req, res) => {
    University.findOne({ _id: req.params.id })
        .then((idea) => {
            idea.name = req.body.name;
            idea.p = req.body.p;
            idea.reason = req.body.reason;
            idea.save()
                .then((idea) => {
                    req.flash('success_msg', 'Data Updated Successfully!');
                    res.redirect('/ms')
                })
        })
})
// routes.get('/ms/temp',(req,res)=>{
//     var nu=[{"name":"Arizona State University","p":61},{"name":"Northeastern University","p":41},{"name":"\nUniversity of Texas at Dallas ","p":52},{"name":"University of Texas at Arlington","p":87},{"name":"University at Buffalo SUNY","p":51},{"name":"Illinois Institute of Technology","p":85},{"name":"Syracuse University","p":64},{"name":"Rochester Institute of Technology","p":91},{"name":"University of Houston","p":70},{"name":"University of Cincinnati","p":93},{"name":"Clemson University","p":44},{"name":"University of South Florida","p":83},{"name":"Stevens Institute of Technology","p":92},{"name":"University of Utah","p":74},{"name":"Colorado State University","p":66},{"name":"Boston University","p":91},{"name":"University of Arizona","p":50},{"name":"University of Pittsburgh","p":53},{"name":"Johns Hopkins University","p":51},{"name":"University of California, Riverside","p":60},{"name":"Texas Tech University","p":74},{"name":"George Washington University","p":70},{"name":"Oregon State University","p":55},{"name":"University of Central Florida","p":95},{"name":"Kansas State University","p":73},{"name":"Worcester Polytechnic Institute","p":65},{"name":"Missouri University of Science and Technology","p":77},{"name":"Drexel University","p":89},{"name":"University of Virginia","p":48},{"name":"University of Dayton","p":86},{"name":"University of Rochester","p":57},{"name":"University of Connecticut","p":65},{"name":"University of Iowa","p":70},{"name":"University of Alabama, Huntsville","p":94},{"name":"Wichita State University","p":91},{"name":"University of Oklahoma","p":65},{"name":"Washington State University","p":55},{"name":"Dartmouth College","p":45},{"name":"University of Kansas","p":77},{"name":"University of Missouri, Columbia","p":93},{"name":"University of South Carolina","p":76},{"name":"University of Delaware","p":79},{"name":"Louisiana State University and A&M College","p":69},{"name":"University of Nebraska, Lincoln","p":60},{"name":"University of Kentucky","p":81}]
//     nu.forEach(element => {
//         const idea = new University({
//             name: element.name,
//             p: element.p
//         });
//         idea.save()
//         .then((idea)=>{
//             console.log(idea);
//         })
        
//     });
// })

module.exports=routes;
