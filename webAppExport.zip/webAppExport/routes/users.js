const express= require('../../exp1UsingMongoDB/express');
const routes= express.Router();
const bcrypt=require('bcryptjs');
const {User}= require('../models/User');
const passport= require('passport');

routes.get('/login', (req, res) => {
    res.render('users/login');
})

routes.get('/register', (req, res) => {
    res.render('users/register');
})

routes.post('/register', async (req, res) => {
    let errors=[];
    if(req.body.password!=req.body.password2)
    {
          errors.push({text:'Passwords do not match'});
    }
    if(req.body.password.length<4)
    {
          errors.push({text:'Passwords must be atleast 4 characters'});
    }
    if(errors.length>0)
    {
        res.render('users/register',{
            errors:errors,
            name:req.body.name,
            email:req.body.email,
            password:req.body.password,
            password2:req.body.password2
        })
    }
    else
    {  
        User.findOne({email:req.body.email})
        .then(async (user)=>{
            if(user) {
                req.flash('error_msg',req.body.email+' is already Registered. Please Login!');
                res.redirect('/users/login');
              }
            else {
                const user= new User({
                    name:req.body.name,
                    email:req.body.email,
                    password:req.body.password
                    });
                //hashing the password
                const salt= await bcrypt.genSalt(10);
                user.password= await bcrypt.hash(req.body.password,salt);
                  
                    user.save()
                    .then((user)=>{
                        req.flash('success_msg', user.name+' Registered Successfully!');
                        res.redirect('/users/login')
                    })
                    
                }
        })
        
    }
})

routes.post('/login', async (req, res,next) => {
    passport.authenticate('local',{
        successRedirect:'/ideas',
        failureRedirect:'/users/login',
        failureFlash:true
    })(req,res,next);
});

routes.get('/logout', (req, res) => {
    req.logout();
    req.flash('success_msg','You are logged out successfully');
    res.redirect('/users/login');
})


module.exports=routes;

