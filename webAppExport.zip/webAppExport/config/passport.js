const LocalStrategy=require('passport-local')
.Strategy;

const mongoose=require('mongoose');
const bcrypt=require('bcryptjs');
var User= mongoose.model('User');

module.exports=function(passport){
    passport.use(new LocalStrategy({usernameField:'email'},
    async (email,password,done)=>{ //take the values of name and email from the form
        //Authenticaton Logic Here
        //done =(errors, users?, Anymessages)
        let user= await User.findOne({email:email});
        if(!user){
           return done(null,false,{message:'No such user found'}); 
        }
        else
        {  const isvalid= await bcrypt.compare(password,user.password);
            if(!isvalid)
            {   //if password is incorrect flash the error and redirect to login page
               return done(null,false,{message:'Incorrect Password!'})
            }
            else
            { //if username and password match then return the user
                return done(null,user)     
            }
        }
    }));

    passport.serializeUser(function(user, done) {
        done(null, user.id);
      });
       
    passport.deserializeUser(function(id, done) {
        User.findById(id, function (err, user) {
          done(err, user);
        });
      });
      
}