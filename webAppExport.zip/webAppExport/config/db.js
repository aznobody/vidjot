var mongoURI='';
if(process.env.NODE_ENV=='production')
{
    mongoURI='mongodb://naveen19:naveen19@ds137404.mlab.com:37404/vidjot-prod'
}
else
{
    mongoURI='mongodb://localhost/nodeWebApp';
}
module.exports.mongoURI=mongoURI;